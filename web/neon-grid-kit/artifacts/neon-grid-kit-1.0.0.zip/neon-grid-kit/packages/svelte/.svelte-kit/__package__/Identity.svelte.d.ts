import type { DecorationProps } from './types.js';
declare const Identity: import("svelte").Component<DecorationProps, {}, "">;
type Identity = ReturnType<typeof Identity>;
export default Identity;
