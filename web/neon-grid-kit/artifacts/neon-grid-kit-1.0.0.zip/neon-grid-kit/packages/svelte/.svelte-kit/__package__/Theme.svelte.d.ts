import type { ThemeProps } from './types.js';
declare const Theme: import("svelte").Component<ThemeProps, {}, "">;
type Theme = ReturnType<typeof Theme>;
export default Theme;
