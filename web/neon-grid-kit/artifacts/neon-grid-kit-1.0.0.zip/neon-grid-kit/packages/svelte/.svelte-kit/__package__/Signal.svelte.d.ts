import type { DecorationProps } from './types.js';
declare const Signal: import("svelte").Component<DecorationProps, {}, "">;
type Signal = ReturnType<typeof Signal>;
export default Signal;
