import type { PanelProps } from './types.js';
declare const Panel: import("svelte").Component<PanelProps, {}, "element">;
type Panel = ReturnType<typeof Panel>;
export default Panel;
