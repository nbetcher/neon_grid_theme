import type { NavItemProps } from './types.js';
declare const NavItem: import("svelte").Component<NavItemProps, {}, "">;
type NavItem = ReturnType<typeof NavItem>;
export default NavItem;
